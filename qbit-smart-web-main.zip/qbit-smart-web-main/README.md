# qBit Smart Web Manager

<p align="center">
  <img src="https://img.shields.io/badge/version-1.18.0-blue.svg" alt="Version">
  <img src="https://img.shields.io/badge/python-3.8+-green.svg" alt="Python">
  <img src="https://img.shields.io/badge/license-MIT-orange.svg" alt="License">
</p>

<p align="center">
  基于 <code>main.py v11.0.0 PRO</code> 智能限速脚本开发的 <b>Web 管理平台</b>
  <br>
  提供美观的界面来管理您的 qBittorrent 和 PT 站点
</p>

---

## 🚀 一键安装

```bash
bash <(curl -sL https://raw.githubusercontent.com/1336665/qbit-smart-web/main/install.sh)
```

运行后显示交互式菜单：

```
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║            ██████╗ ██████╗ ██╗████████╗    ███████╗███╗   ███╗            ║
║           ██╔═══██╗██╔══██╗██║╚══██╔══╝    ██╔════╝████╗ ████║            ║
║           ██║   ██║██████╔╝██║   ██║       ███████╗██╔████╔██║            ║
║           ██║▄▄ ██║██╔══██╗██║   ██║       ╚════██║██║╚██╔╝██║            ║
║           ╚██████╔╝██████╔╝██║   ██║       ███████║██║ ╚═╝ ██║            ║
║            ╚══▀▀═╝ ╚═════╝ ╚═╝   ╚═╝       ╚══════╝╚═╝     ╚═╝            ║
║                                                                           ║
║                    qBit Smart Web Manager v1.18                           ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

请选择操作:

  1) 全新安装          # 自动安装依赖 + 可选配置域名/HTTPS
  2) 更新程序          # 保留数据库，只更新代码
  3) 配置域名/HTTPS    # Nginx反代 + Let's Encrypt证书
  4) 查看状态
  5) 重启服务
  6) 查看日志
  7) 卸载
  0) 退出
```

### 📌 一键脚本功能

| 功能 | 说明 |
|-----|------|
| ✅ 自动安装依赖 | Python、pip、nginx、certbot 等 |
| ✅ 自动配置服务 | systemd 服务，开机自启 |
| ✅ 绑定域名 | Nginx 反向代理 |
| ✅ 自动 HTTPS | Let's Encrypt 免费证书，自动续期 |
| ✅ 一键更新 | 保留数据库和配置 |
| ✅ 一键卸载 | 可选保留数据 |

---

## ✨ 功能特性

| 功能模块 | 说明 |
|---------|------|
| 🖥️ **多qB实例管理** | 按剩余空间自动分配种子 |
| 🎯 **智能限速** | PID/Kalman控制器，4阶段动态参数 |
| 📡 **RSS自动抓取** | Vertex风格，只抓取真正新发布的种子 |
| 🗑️ **自动删种** | 8个内置规则，删前强制汇报 |
| 🌐 **通用PT站点辅助器** | 支持所有NexusPHP站点 |
| 📥 **下载限速 + 汇报优化** | 防止超速，智能汇报时机 |
| 💾 **种子状态持久化** | 重启后恢复限速状态 |
| 📲 **Telegram通知** | 启动/添加/删除/警告 |
| 🔐 **认证系统** | 首次设置密码，会话管理 |
| 📦 **配置导入/导出** | JSON格式备份恢复 |

---

## 📸 截图预览

<details>
<summary>点击展开截图</summary>

### 仪表盘
![Dashboard](docs/images/dashboard.png)

### 站点管理
![Sites](docs/images/sites.png)

### 设置页面
![Settings](docs/images/settings.png)

</details>

---

## ⚙️ 服务管理

安装完成后，可以使用以下命令管理服务：

```bash
# 启动
systemctl start qbit-smart

# 停止
systemctl stop qbit-smart

# 重启
systemctl restart qbit-smart

# 查看状态
systemctl status qbit-smart

# 查看日志
journalctl -u qbit-smart -f

# 再次运行管理菜单
bash <(curl -sL https://raw.githubusercontent.com/1336665/qbit-smart-web/main/install.sh)
```

---

## 🔧 手动安装

如果一键脚本不适用于您的环境，可以手动安装：

```bash
# 1. 安装系统依赖
apt update
apt install -y python3 python3-pip curl wget unzip

# 2. 安装 Python 依赖
pip3 install --break-system-packages flask requests beautifulsoup4 lxml feedparser qbittorrent-api

# 3. 下载程序
mkdir -p /opt/qbit-smart-web
cd /opt/qbit-smart-web
wget https://github.com/1336665/qbit-smart-web/archive/refs/heads/main.zip
unzip main.zip
mv qbit-smart-web-main/* .
rm -rf qbit-smart-web-main main.zip

# 4. 运行
python3 app.py

# 5. 访问 http://你的IP:5000
```

---

## 📋 环境变量

| 变量 | 默认值 | 说明 |
|-----|-------|------|
| `PORT` | 5000 | 监听端口 |
| `HOST` | 0.0.0.0 | 监听地址 |
| `SECRET_KEY` | 随机生成 | Session密钥 |
| `DEBUG` | false | 调试模式 |

---

## ❓ 常见问题

### Q: 安装依赖报错 `externally-managed-environment`

```bash
# 使用 --break-system-packages 参数
pip3 install --break-system-packages flask requests beautifulsoup4 lxml feedparser qbittorrent-api
```

### Q: 如何更改端口？

重新运行一键脚本，选择「全新安装」并输入新端口，或手动编辑：

```bash
systemctl edit qbit-smart --full
# 修改 Environment="PORT=5000" 中的端口号
systemctl daemon-reload
systemctl restart qbit-smart
```

### Q: HTTPS 证书续期

证书会自动续期，可以手动测试：
```bash
certbot renew --dry-run
```

### Q: 忘记密码怎么办？

删除数据库重新设置：
```bash
rm /opt/qbit-smart-web/qbit_smart.db
systemctl restart qbit-smart
```

### Q: 如何查看运行日志？

```bash
# 实时查看
journalctl -u qbit-smart -f

# 查看最近100行
journalctl -u qbit-smart -n 100
```

---

## 📝 更新日志

### v1.18.0 (2025-01-06)
- 🐛 **修复多行Cookie格式问题** - 从浏览器复制的多行Cookie会自动合并为单行
- 🐛 **修复URL不可见字符问题** - 自动清理URL中的BOM、零宽字符等
- 🐛 **修复Cookie验证逻辑** - 随便填Cookie不再能通过验证
- ✨ RSS默认最大种子年龄从10分钟改为60分钟
- ✨ RSS每次最大添加种子数从5个改为10个

### v1.16.0 (2025-01-05)
- 🐛 修复 Cookie 检测 401 错误
- 🐛 修复移动端设置页面按钮溢出
- 🐛 修复添加站点按钮 loading 变形
- 🐛 修复限速状态显示错误

[查看完整更新日志](CHANGELOG.md)

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

MIT License
